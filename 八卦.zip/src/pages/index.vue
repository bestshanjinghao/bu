<template>
    <div>
        <qiGua></qiGua>
    </div>
</template>
  
<script>
import qiGua from '../components/qigua2.vue'

export default {
    name: 'IndexPage',
    components: {
        qiGua,
    }
}
</script>
  
<style></style>
  