<template>
    <div>
        根据主互变的情况，分析出吉凶 即理的部分
        用克体 体克用 用生体 体生用 比和
    </div>
</template>
  
<script>
export default {
    name: 'tiYong',
    props: {
        msg: String
    }
}
</script>
  
<style scoped></style>
  