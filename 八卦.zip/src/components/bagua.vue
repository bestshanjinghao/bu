<template>
    <div>
        <div>
            子1、丑2、寅3、卯4、辰5、巳6、午7、未8、申9、酉10、戌11、亥12
        </div>


    </div>
</template>
  
<script>
export default {
    name: 'baGua',
    props: {
        msg: String
    },
    components: {

    },
    data() {
        return {
        }
    },

    methods: {},
    mounted() {

    }
}

</script>
  
<style lang="scss" scoped></style>
  