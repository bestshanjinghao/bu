<template>
    <div>
        万物类象
    </div>
</template>
  
<script>
export default {
    name: 'tiYong',
    props: {
        msg: String
    }
}
</script>
  
<style scoped></style>
  